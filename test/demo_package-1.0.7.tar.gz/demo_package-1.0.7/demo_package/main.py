from demo_target import __about__

print(__about__.__version__)